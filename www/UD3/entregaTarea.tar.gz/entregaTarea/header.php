<header class="bg-primary text-white text-center py-3">
    <h1>Gestión de tareasy usuarios</h1>
    <p>Tarea unidad 3 de DWCS</p>
</header>