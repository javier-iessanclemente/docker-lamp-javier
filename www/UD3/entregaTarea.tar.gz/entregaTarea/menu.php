<nav class="col-md-3 col-lg-2 d-md-block bg-light sidebar">
    <div class="position-sticky">
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link" href="index.php">
                    Home
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="usuarios.php">
                    Lista de usuarios
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="nuevoUsuarioForm.php">
                    Nuevo usuario
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="tareas.php">
                    Lista de tareas
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="nuevaForm.php">
                    Nueva tarea
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="buscaTareas.php">
                    Buscador de tareas
                </a>
            </li>
        </ul>
    </div>
</nav>